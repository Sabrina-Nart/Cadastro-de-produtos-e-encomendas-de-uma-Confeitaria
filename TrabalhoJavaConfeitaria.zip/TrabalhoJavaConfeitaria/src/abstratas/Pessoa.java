
package abstratas;

abstract public class Pessoa extends Dados{
    
    private String CPF;
    private String Telefone;
    private String Endereco;

    public Pessoa() {
        super();
        this.setCPF("000.000.000-00");
        this.setTelefone("(00) 00000-0000");
        this.setEndereco("VÁZIO");
    }
    
    public Pessoa(String nome, String CPF, String Telefone, String Endereco) {
        super(nome);
        this.setCPF(CPF);
        this.setTelefone(Telefone);
        this.setEndereco(Endereco);
    }
    
////////////////
    
    public void setCPF(String CPF) {
        this.CPF = CPF.trim().isEmpty() ? "000.000.000-00" : CPF;
    }

    public void setTelefone(String Telefone) {
        this.Telefone = Telefone.trim().isEmpty() ? "(00) 00000-0000" : Telefone;
    }

    public void setEndereco(String Endereco) {
        this.Endereco = Endereco.trim().isEmpty() ? "VÁZIO" : Endereco.toUpperCase();
    }
    
////////////////
    
    public String getCPF() {
        return this.CPF;
    }

    public String getTelefone() {
        return this.Telefone;
    }

    public String getEndereco() {
        return this.Endereco;
    }
    
////////////////    
}
