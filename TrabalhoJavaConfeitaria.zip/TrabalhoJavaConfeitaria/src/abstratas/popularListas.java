
package abstratas;

import classes.Bolo;
import classes.Cliente;
import classes.Confeiteiro;
import classes.Docinho;
import classes.Salgado;
import enums.Especialidade;
import enums.Sexo;
import enums.TipoSalgado;
import java.time.LocalDate;
import java.time.Month;

abstract public class popularListas {
    
    public static void addObjetos(){
        
        //Objetos Confeiteiro
        Confeiteiro confeiteiro1 = new Confeiteiro("Maynara Colombo", "892.116.048-50", "(48) 98769-9768", "Siderópolis", Especialidade.BL, LocalDate.of(2020, 07, 26));
        Confeiteiro confeiteiro2 = new Confeiteiro("Nathalia Simone Luna", "750.217.010-37", "(48) 98297-3391", "Criciúma", Especialidade.BL, LocalDate.of(2020, 9, 22));
        Confeiteiro confeiteiro3 = new Confeiteiro("Luan Vicente Aragão", "985.872.748-80", "(48) 99569-0768", "Siderópolis", Especialidade.DC, LocalDate.of(2020, 07, 26));
        Confeiteiro confeiteiro4 = new Confeiteiro("Keyla Caldeira", "076.120.763-57", "(48) 99937-7235", "Criciúma", Especialidade.SD, LocalDate.of(2021, 10, 12));
        Confeiteiro confeiteiro5 = new Confeiteiro("Lara Vieira Bragança", "287.895.724-59", "(48) 99740-8257", "Nova Veneza", Especialidade.BL, LocalDate.of(2022, 02, 15));
        
        //Objetos Cliente
        Cliente cliente1 = new Cliente("Sabrina Marques", "335.125.042-80", "(48) 98365-7665", "Siderópolis", Sexo.FE, "Paga adiantado");
        Cliente cliente2 = new Cliente("Isadora Barbosa", "654.196.005-44", "(48) 99264-8753", "Siderópolis", Sexo.FE, "Paga adiantado");
        Cliente cliente3 = new Cliente("Jamily Maitê Benedita", "654.196.005-44", "(48) 99264-8753", "Treviso", Sexo.FE, "Paga no cartão");
        Cliente cliente4 = new Cliente("Francieli Tereza Cláudia Brito", "684.057.319-20", "(48) 99603-0060", "Criciúma", Sexo.FE, "Paga no PIX");
        Cliente cliente5 = new Cliente("Enzo Gabriel Rodrigo Calebe Melo", "116.765.760-88", "(48) 98955-4135", "Criciúma", Sexo.MA, "Paga depois da entrega");
 
        //Objetos Bolo
        Bolo bolo1 = new Bolo("Brigadeiro", 40, "Chiffon");
        Bolo bolo2 = new Bolo("Musse de Morango", 40, "Génoise");
        Bolo bolo3 = new Bolo("Coco", 40, " Pão-de-ló");
        Bolo bolo4 = new Bolo("Sonho de Valsa", 40, "Amanteigada");
        Bolo bolo5 = new Bolo("Quatro Leites com Bombom", 40, "Amanteigada");
        
        //Objetos Docinhos
        Docinho docinhos1 = new Docinho("Tradicional", 80, "Brigadeiro");
        Docinho docinhos2 = new Docinho("Camuflado", 80, "Prestígio");
        Docinho docinhos3 = new Docinho("Gourmet", 80, "Ninho com Nutella");
        Docinho docinhos4 = new Docinho("Supreme", 80, "Ferrero Roche");
        Docinho docinhos5 = new Docinho("Fino", 80, "Copinho de Chocolate");
        
        //Objetos Salgado
        Salgado salgado1 = new Salgado("Coxinha", 75, confeiteiro4, TipoSalgado.FR);
        Salgado salgado2 = new Salgado("Bolinha de Queijo", 75, confeiteiro4, TipoSalgado.FR);
        Salgado salgado3 = new Salgado("Enroladinho de salsicha", 75, confeiteiro2, TipoSalgado.AS);
        Salgado salgado4 = new Salgado("Rissole de Frango", 75, confeiteiro5, TipoSalgado.FR);
        Salgado salgado5 = new Salgado("Empadinhas", 75, confeiteiro3, TipoSalgado.AS);
        
    ////////////////

        Listas.getListaConfeiteiro().add(confeiteiro1);
        Listas.getListaConfeiteiro().add(confeiteiro2);
        Listas.getListaConfeiteiro().add(confeiteiro3);
        Listas.getListaConfeiteiro().add(confeiteiro4);
        Listas.getListaConfeiteiro().add(confeiteiro5);
    
    ////////////////
    
        Listas.getListaCliente().add(cliente1);
        Listas.getListaCliente().add(cliente2);
        Listas.getListaCliente().add(cliente3);
        Listas.getListaCliente().add(cliente4);
        Listas.getListaCliente().add(cliente5);
        
    ////////////////   
    
        Listas.getListaBolo().add(bolo1);   
        Listas.getListaBolo().add(bolo2);  
        Listas.getListaBolo().add(bolo3);  
        Listas.getListaBolo().add(bolo4);  
        Listas.getListaBolo().add(bolo5);  

    //////////////// 
    
        Listas.getListaDocinho().add(docinhos1);
        Listas.getListaDocinho().add(docinhos2);
        Listas.getListaDocinho().add(docinhos3);
        Listas.getListaDocinho().add(docinhos4);
        Listas.getListaDocinho().add(docinhos5);      
    
    ////////////////   
        
        Listas.getListaSalgado().add(salgado1);
        Listas.getListaSalgado().add(salgado2);
        Listas.getListaSalgado().add(salgado3);
        Listas.getListaSalgado().add(salgado4);
        Listas.getListaSalgado().add(salgado5);
    
    ////////////////   
    
    }
}
