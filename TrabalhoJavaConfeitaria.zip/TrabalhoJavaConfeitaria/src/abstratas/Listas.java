
package abstratas;

import classes.Bolo;
import classes.Cliente;
import classes.Confeiteiro;
import classes.Docinho;
import classes.Encomenda;
import classes.Salgado;
import java.util.LinkedList;

abstract public class Listas {
    
    private static LinkedList<Confeiteiro> listaConfeiteiro = new LinkedList<>();
    private static LinkedList<Cliente> listaCliente = new LinkedList<>();
    private static LinkedList<Bolo> listaBolo = new LinkedList<>();
    private static LinkedList<Docinho> listaDocinho = new LinkedList<>();
    private static LinkedList<Salgado> listaSalgado = new LinkedList<>();
    private static LinkedList<Encomenda> listaEncomenda = new LinkedList<>();

    public static LinkedList<Confeiteiro> getListaConfeiteiro() {
        return listaConfeiteiro;
    }

    public static LinkedList<Cliente> getListaCliente() {
        return listaCliente;
    }

    public static LinkedList<Bolo> getListaBolo() {
        return listaBolo;
    }

    public static LinkedList<Docinho> getListaDocinho() {
        return listaDocinho;
    }

    public static LinkedList<Salgado> getListaSalgado() {
        return listaSalgado;
    }

    public static LinkedList<Encomenda> getListaEncomenda() {
        return listaEncomenda;
    }
         
}
