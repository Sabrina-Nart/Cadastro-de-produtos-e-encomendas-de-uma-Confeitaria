
package abstratas;

abstract public class Produto extends Dados{
 
    private double valor;
    
    public Produto(){
        super();
        this.setValor(0.01);
    }
    
////////////////
    
    public Produto(String nome, double valor){
        super(nome);
        this.setValor(valor);
    }
    
////////////////
    
    public void setValor(double valor) {
        this.valor = valor <= 0 ? 0.01 : valor;
    }
    
////////////////
    
    public double getValor() {
        return this.valor;
    } 
    
////////////////    
}
