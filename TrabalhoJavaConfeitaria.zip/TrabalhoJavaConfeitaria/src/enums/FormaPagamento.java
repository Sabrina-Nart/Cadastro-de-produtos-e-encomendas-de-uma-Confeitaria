
package enums;

public enum FormaPagamento {

    DN("Dinheiro"),
    PX("PIX"),
    CC("Cartão de Crédito"),
    CD("Cartão de Débito");
    
    private String descricao;

    private FormaPagamento(String descricao) {
        this.descricao = descricao;
    }
    
////////////////  
    
    @Override
    public String toString() {
        return descricao;
    }
    
////////////////      
}
