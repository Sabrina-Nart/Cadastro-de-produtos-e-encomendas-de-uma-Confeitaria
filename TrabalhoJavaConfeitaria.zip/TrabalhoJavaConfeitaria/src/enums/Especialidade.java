
package enums;

public enum Especialidade {

    BL("Bolo"),
    SD("Salgado"),
    DC("Docinho");
    
    private String descricao;

    private Especialidade(String descricao) {
        this.descricao = descricao;
    }
    
////////////////
    
    @Override
    public String toString() {
        return descricao;
    }
    
////////////////    
}
