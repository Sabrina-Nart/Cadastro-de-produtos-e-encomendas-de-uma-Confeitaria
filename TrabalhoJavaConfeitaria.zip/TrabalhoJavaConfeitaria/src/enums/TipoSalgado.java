
package enums;

public enum TipoSalgado {
    
    FR("Frito"),
    AS("Assado");
    
    private String descricao;

    private TipoSalgado(String descricao) {
        this.descricao = descricao;
    }
    
////////////////
    
    @Override
    public String toString() {
        return descricao;
    }
    
////////////////    
}
