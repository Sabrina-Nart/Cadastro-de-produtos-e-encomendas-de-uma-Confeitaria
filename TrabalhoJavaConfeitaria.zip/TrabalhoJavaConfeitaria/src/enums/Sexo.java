
package enums;

public enum Sexo {

    FE("Feminino"),
    MA("Masculino");
    
    private String descricao;

    private Sexo(String descricao) {
        this.descricao = descricao;
    }
    
////////////////
    
    @Override
    public String toString() {
        return descricao;
    }
    
////////////////    
}
