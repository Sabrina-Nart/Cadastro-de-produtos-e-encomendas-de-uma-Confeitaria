
package classes;

import enums.FormaPagamento;
import java.time.LocalDate;
import java.util.LinkedList;

public class Encomenda {

    private int codigo;
    private Confeiteiro confeiteiro;
    private Cliente cliente;
    private FormaPagamento formaPagamento;
    private LocalDate data;
    private String total;
    private LinkedList<Item> encomenda = new LinkedList();

    public Encomenda() {
        this.setCodigo(0);
        this.setConfeiteiro(null);
        this.setCliente(null);
        this.setFormaPagamento(formaPagamento.DN);
        this.setData(LocalDate.now());
        this.setTotal("000.00");
    }
    
////////////////  
    
    public Encomenda(int codigo, Confeiteiro confeiteiro, Cliente cliente, FormaPagamento formaPagamento, LocalDate data, String total) {
        this.setCodigo(codigo);
        this.setConfeiteiro(confeiteiro);
        this.setCliente(cliente);
        this.setFormaPagamento(formaPagamento);
        this.setData(data);
        this.setTotal(total);
    }
    
////////////////  
    
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setConfeiteiro(Confeiteiro confeiteiro) {
        this.confeiteiro = confeiteiro == null ? new Confeiteiro() : confeiteiro;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente == null ? new Cliente() : cliente;
    }

    public void setFormaPagamento(FormaPagamento formaPagamento) {
        this.formaPagamento = formaPagamento;
    }
    
    public void setData(LocalDate data) {
        this.data = data==null ? LocalDate.now() : data;
    }

    public void setTotal(String total) {
        this.total = total.trim().isEmpty() ? "000.00" : total;
    }    
    
////////////////  
    
    public int getCodigo() {
        return this.codigo;
    }

    public Confeiteiro getConfeiteiro() {
        return this.confeiteiro;
    }

    public Cliente getCliente() {
        return this.cliente;
    }

    public FormaPagamento getFormaPagamento() {
        return this.formaPagamento;
    }
    
    public LocalDate getData() {
        return this.data;
    }

    public String getTotal() {
        return this.total;
    }

    public LinkedList<Item> getEncomenda() {
        return this.encomenda;
    }
    
////////////////  
    
    @Override
    public String toString() {
        return this.codigo + " - " + this.confeiteiro + " - " + this.cliente;
    }   
    
////////////////    
}
