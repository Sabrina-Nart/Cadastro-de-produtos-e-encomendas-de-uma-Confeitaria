
package classes;

import abstratas.Produto;

public class Docinho extends Produto{
    
    private String sabor;

    public Docinho() {
        super();
        this.setSabor("SEM PEDIDO");
    }
    
////////////////
    
    public Docinho(String nome, double valor, String sabor) {
        super(nome, valor);
        this.setSabor(sabor);
    }
    
////////////////
    
    public void setSabor(String sabor) {
        this.sabor = sabor.trim().isEmpty() ? "SEM PEDIDO" : sabor.toUpperCase();;
    }
    
////////////////
    
    public String getSabor() {
        return this.sabor;
    }
       
////////////////    
}
