
package classes;

import abstratas.Pessoa;
import enums.Sexo;

public class Cliente extends Pessoa{

    private Sexo sexo;
    private String complemento;

    public Cliente() {
        super();
        this.setSexo(Sexo.FE);
        this.setComplemento("VÁZIO");
    }

    public Cliente(String nome, String CPF, String Telefone, String Endereco, Sexo sexo, String complemento) {
        super(nome, CPF, Telefone, Endereco);
        this.setSexo(sexo);
        this.setComplemento(complemento);
    }
    
////////////////
    
    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }
    
    public void setComplemento(String complemento) {
        this.complemento = complemento.trim().isEmpty() ? "VÁZIO" : complemento.toUpperCase();
    }
    
////////////////
    
    public Sexo getSexo() {
        return this.sexo;
    }

    public String getComplemento() {
        return this.complemento;
    }
    
////////////////
}
