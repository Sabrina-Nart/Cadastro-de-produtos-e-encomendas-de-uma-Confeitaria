
package classes;

import abstratas.Produto;
import enums.TipoSalgado;

public class Salgado extends Produto{
    
    private Confeiteiro confeiteiro;
    private TipoSalgado tipoSalgado;

    public Salgado() {
        super();
        this.setConfeiteiro(null);
        this.setTipoSalgado(tipoSalgado.AS);
    }
    
    public Salgado(String nome, double valor, Confeiteiro confeiteiro, TipoSalgado tipoSalgado) {
        super(nome, valor);
        this.setConfeiteiro(confeiteiro);
        this.setTipoSalgado(tipoSalgado);
    }
    
////////////////

    public void setConfeiteiro(Confeiteiro confeiteiro) {
        this.confeiteiro = confeiteiro == null ? new Confeiteiro() : confeiteiro;
    }
     
    
    public void setTipoSalgado(TipoSalgado tipoSalgado) {
        this.tipoSalgado = tipoSalgado;
    }
    
////////////////
    
    public Confeiteiro getConfeiteiro() {
        return this.confeiteiro;
    }  
    
    public TipoSalgado getTipoSalgado() {
        return this.tipoSalgado;
    }
////////////////
}
