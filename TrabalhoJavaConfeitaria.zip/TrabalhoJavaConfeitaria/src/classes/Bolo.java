
package classes;

import abstratas.Produto;

public class Bolo extends Produto{
    
    private String massa;

    public Bolo(){
        super();
        this.setMassa("SEM PEDIDO");       
    }
    
//////////////// 
    
    public Bolo(String nome, double valor, String massa) {
        super(nome, valor);
        this.setMassa(massa);
    }
    
////////////////

    public void setMassa(String massa) {
        this.massa = massa.trim().isEmpty() ? "SEM PEDIDO" : massa.toUpperCase();;
    }
    
////////////////

    public String getMassa() {
        return this.massa;
    }
    
////////////////    
}
