
package classes;

import abstratas.Pessoa;
import enums.Especialidade;
import java.time.LocalDate;
import java.time.Month;

public class Confeiteiro extends Pessoa{
    
    private Especialidade especialidade;
    private LocalDate contrataco;

    public Confeiteiro() {
        super();
        this.setEspecialidade(especialidade.BL);
        this.setContrataco(null);
    } 
    
    public Confeiteiro(String nome, String CPF, String Telefone, String Endereco, Especialidade especialidade, LocalDate contrataco) {
        super(nome, CPF, Telefone, Endereco);
        this.setEspecialidade(especialidade);
        this.setContrataco(contrataco);
    } 
    
////////////////
    
    public void setEspecialidade(Especialidade especialidade) {
        this.especialidade = especialidade;
    }

    public void setContrataco(LocalDate contrataco) {
        this.contrataco = contrataco == null ? LocalDate.of(2019, Month.JANUARY, 1) : contrataco;
    }
    
////////////////
    
    public Especialidade getEspecialidade() {
        return this.especialidade;
    }

    public LocalDate getContrataco() {
        return this.contrataco;
    }
    
////////////////
    
    @Override
    public String toString() {
        return super.getNome() + " - " + this.especialidade;
    }

////////////////    
}
