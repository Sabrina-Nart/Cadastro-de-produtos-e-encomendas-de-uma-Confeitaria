
package forms;

import abstratas.popularListas;

public class frameMenu extends javax.swing.JFrame {

    public frameMenu() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        itemConfeiteiro = new javax.swing.JMenuItem();
        itemCliente = new javax.swing.JMenuItem();
        itemBolo = new javax.swing.JMenuItem();
        itemDocinho = new javax.swing.JMenuItem();
        itemSalgadinho = new javax.swing.JMenuItem();
        itemEncomenda = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 228, 225));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 942, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 670, Short.MAX_VALUE)
        );

        jMenu1.setText("Arquivos");
        jMenu1.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N

        itemConfeiteiro.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        itemConfeiteiro.setText("Confeiteiro");
        itemConfeiteiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemConfeiteiroActionPerformed(evt);
            }
        });
        jMenu1.add(itemConfeiteiro);

        itemCliente.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        itemCliente.setText("Cliente");
        itemCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemClienteActionPerformed(evt);
            }
        });
        jMenu1.add(itemCliente);

        itemBolo.setText("Bolo");
        itemBolo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemBoloActionPerformed(evt);
            }
        });
        jMenu1.add(itemBolo);

        itemDocinho.setText("Docinho");
        itemDocinho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemDocinhoActionPerformed(evt);
            }
        });
        jMenu1.add(itemDocinho);

        itemSalgadinho.setText("Salgadinho");
        itemSalgadinho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemSalgadinhoActionPerformed(evt);
            }
        });
        jMenu1.add(itemSalgadinho);

        itemEncomenda.setText("Encomenda");
        itemEncomenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemEncomendaActionPerformed(evt);
            }
        });
        jMenu1.add(itemEncomenda);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void itemConfeiteiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemConfeiteiroActionPerformed
    
        new dialogConfeiteiro(this, true).setVisible(true);
    }//GEN-LAST:event_itemConfeiteiroActionPerformed

    private void itemClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemClienteActionPerformed
        
        new dialogCliente(this, true).setVisible(true);
    }//GEN-LAST:event_itemClienteActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       
        popularListas.addObjetos();
    }//GEN-LAST:event_formWindowOpened

    private void itemBoloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemBoloActionPerformed
        
        new dialogBolo(this, true).setVisible(true);
    }//GEN-LAST:event_itemBoloActionPerformed

    private void itemDocinhoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemDocinhoActionPerformed
        
        new dialogDocinho(this, true).setVisible(true);
    }//GEN-LAST:event_itemDocinhoActionPerformed

    private void itemSalgadinhoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemSalgadinhoActionPerformed
       
        new dialogSalgado(this, true).setVisible(true);
    }//GEN-LAST:event_itemSalgadinhoActionPerformed

    private void itemEncomendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemEncomendaActionPerformed
        
        new dialogEncomenda(this, true).setVisible(true);
    }//GEN-LAST:event_itemEncomendaActionPerformed


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frameMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frameMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frameMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frameMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frameMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem itemBolo;
    private javax.swing.JMenuItem itemCliente;
    private javax.swing.JMenuItem itemConfeiteiro;
    private javax.swing.JMenuItem itemDocinho;
    private javax.swing.JMenuItem itemEncomenda;
    private javax.swing.JMenuItem itemSalgadinho;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
